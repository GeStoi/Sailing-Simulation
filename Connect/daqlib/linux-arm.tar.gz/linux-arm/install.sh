#! /bin/sh
cp ./libusb.rules /etc/udev/rules.d/

target_dir="/usr/local/lib/daqlib"

if [ ! -d $target_dir ]; then
    mkdir $target_dir
fi

cp ./libdaqlib.so.1.0.0 libdaqlib.so libdaqlib.so.1 libdaqlib.so.1.0  $target_dir


