#! /bin/sh
cp ./libusb.rules /etc/udev/rules.d/

target_dir="/usr/local/lib/daqlib"

rm -rf $target_dir
